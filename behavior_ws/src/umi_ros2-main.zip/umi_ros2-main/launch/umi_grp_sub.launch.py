from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory

import os


def generate_launch_description():
    package_share = get_package_share_directory('umi_ros2')
    default_config = os.path.join(package_share, 'config', 'umi_grp_sub.yaml')
    config_arg = DeclareLaunchArgument(
        'config_file',
        default_value=default_config,
        description='Path to the parameter file for umi_gripper_sub.',
    )

    node = Node(
        package='umi_ros2',
        executable='umi_gripper_sub',
        name='umi_gripper_sub',
        output='screen',
        parameters=[LaunchConfiguration('config_file')],
    )

    return LaunchDescription([config_arg, node])
